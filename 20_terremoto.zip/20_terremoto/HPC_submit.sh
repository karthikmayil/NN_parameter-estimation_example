#!/bin/sh
#
# Simple "Hello World" submit script for Slurm.
#
# Replace <ACCOUNT> with your account name before submitting.
#
#SBATCH --account=cheme          # The account name for the job.
#SBATCH --job-name=aging       # The job name.
#SBATCH -c 1                     # The number of cpu cores to use.
#SBATCH --time=00:45:00              # The time the job will take to run.
#SBATCH --mem-per-cpu=4gb        # The memory the job will use per cpu core.
 
# run the fortran code
gfortran *.f95
./a.out

# remove extraneous files
rm ./a.out
rm *.mod
rm slurm*
rm *.f95
rm *.56
rm *.sh
