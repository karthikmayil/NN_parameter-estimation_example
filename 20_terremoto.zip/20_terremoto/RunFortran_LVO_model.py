######################################
#### IMPORT NECESSARY PACKAGES #######
######################################

import numpy as np                          # Useful for numerical calculations on an array
import time
import os                                   # Used for changing directories and open files with folders
import pandas as pd                         # Used to read csv files
import matplotlib.pyplot as plt             # Used for making plots
import sobol_seq                              # Sobol Package used to generate Sobol Sequence
import math
from matplotlib.ticker import FormatStrFormatter
import sys
from subprocess import call                 # Allows Python to call shell script
import shutil
import re
import glob
import random
from operator import itemgetter             # Allows us to find groups of consecutive numbers
from itertools import groupby
import scipy.stats as stats
from scipy.optimize import minimize
from scipy.special import erf               # error function (erf)
from itertools import combinations          # used to make combinations of variables for lasso method
from tqdm import tqdm, trange


###### DEFINE HELPER FUNCTIONS ######
### Run_Model Function is no longer necessary
def Run_Model(Input_Parameters, Model_Folder, Shell_Script):

	# PASS PARAMETERS TO SHELL SCRIPT
	cmd = ['bash', Shell_Script]
	for param in Input_Parameters:
		cmd.append(str(param))

	# RUN MODEL USING SHELL SCRIPT
	p = call(cmd)               # run model


def sed(pattern, replace, source, dest=None, count=0):
	"""Reads a source file and writes the destination file.

	In each line, replaces pattern with replace.

	Args:
		pattern (str): pattern to match (can be re.pattern)
		replace (str): replacement str
		source  (str): input filename
		count (int):   number of occurrences to replace
		dest (str):    destination filename, if not given, source will be over written.
	"""

	fin = open(source, 'r')
	num_replaced = count

	if dest:
		fout = open(dest, 'w')
	else:
		fd, name = mkstemp()
		fout = open(name, 'w')

	for line in fin:
		out = re.sub(pattern, replace, line)
		fout.write(out)

		if out != line:
			num_replaced += 1
		if count and num_replaced > count:
			break
	try:
		fout.writelines(fin.readlines())
	except Exception as E:
		raise E

	fin.close()
	fout.close()

	if not dest:
		shutil.move(name, source)


###################################################
#################### FILE LIST ####################
###################################################
fortran_code = 'LVO_model_beta_v9.f95'
fortran_code_values = 'LVO_model_Values.f95'
HPC_script  = 'HPC_submit.sh'


HPC = True # variable to indicate if the simulations are being run on the cluster or locally
###################################################
## CREATE NEW DIRECTORIES FOR EACH CURRENT RATE ###
###################################################
cwd = os.getcwd() # current working directory

#text_to_replace = ['AM_LOADING','COND_LOADING','BIND_LOADING','THICKNESS','EXPCURR', 'TSTEP']#,'CRATE','ELEC_NODES','XTAL_NODES']

# fixed values for each experiment
fixed_text_to_replace = {'THICKNESS':370.0, 'AM_LOADING':0.020461}
text_to_replace = ['AML_ADJ','DF_A','I0_A','CRATE','XTAL_NODES','THICKNESS','AM_LOADING']


iterations = []
for file in os.listdir():
	if file.startswith('Simulation_Parameters'):
		iterations.append(int(file.split('_I')[1].split('.')[0]))

i_latest = np.max(iterations)
latest_iteration_filename = 'Simulation_Parameters_I'+str(i_latest)+'.csv'
sim_table = pd.read_csv(latest_iteration_filename,sep=',')



for i in sim_table.index:
	os.chdir(cwd)

	# directory to run and store the code cwd/CurrentRate/Length/Porosity/
	# if that target directory does not exist yet, create it
	value_dir = cwd+'/Simulations/'+str(i)

	if not(os.path.exists(value_dir)):
		os.makedirs(value_dir)

	# numeric values for all the relevant parameters, fixed and variable
	text_values = list(sim_table.loc[i,['AML_ADJ','DF_A','I0_A','CRATE','XTAL_NODES']]) + list(fixed_text_to_replace.values())

	# add values for each simulation to dictionary for printing
	try:
		TVT = pd.read_csv(value_dir+'/Time_Voltage.txt',delim_whitespace=True,skiprows=[1])
		fV = TVT.loc[TVT['Voltage']<2.2]['Voltage'].values[0]
		continue
	except (FileNotFoundError,IndexError,pd.errors.EmptyDataError) as e:
		print(value_dir,'running')
		print(text_values)

	_source = cwd + '/' + fortran_code
	_source_HPC = cwd + '/' + HPC_script

	for o, text in enumerate(text_to_replace):
		#print(o, text, str(text_values[o]))
		# loop thru fortran code
		_dest = cwd + '/' + 'fortran_temp_' + str(o) + '.f95'
		sed(text, str(text_values[o]), _source, _dest )
		_source = _dest

		if HPC == True:
			# loop thru HPC script
			_dest_HPC = cwd + '/' + 'HPC_temp_' + str(o) + '.sh'
			sed(text, str(text_values[o]), _source_HPC, _dest_HPC)
			_source_HPC = _dest_HPC

	# move the files with values to the corresponding directory
	shutil.move(_source, value_dir + '/' +  fortran_code_values)

	if HPC == True:
		shutil.move(_source_HPC, value_dir + '/' + HPC_script)

	# navigate to the directory containing the fortran code with values
	os.chdir(value_dir)

	if HPC == False:
		# complile and run the fortran code
		p = call(['gfortran', fortran_code_values])
		p = call(['./a.out'])

		# remove executable and module files
		p = call(['rm', 'a.out'])
		for fl in glob.glob('*.mod'):
			os.remove(fl)
		for fl in glob.glob('*Values*'):
			os.remove(fl)
		for fl in glob.glob('*.56'):
			os.remove(fl)

	if HPC == True:

		os.system('squeue -u km3400 | wc -l > running_jobs.txt')
		num_jobs = pd.read_csv(value_dir+'/running_jobs.txt',header=None).values[0][0]
		while  num_jobs > 4500:
			time.sleep(60)
			os.system('squeue -u km3400 | wc -l > running_jobs.txt')
			num_jobs = pd.read_csv(value_dir+'/running_jobs.txt',header=None).values[0][0]

		p = call(['rm','running_jobs.txt'])

		p = call(['sbatch', HPC_script])
		time.sleep(0.1)

# remove all temporary files
os.chdir(cwd)
for fl in glob.glob('*temp*'):
	os.remove(fl)

for fl in glob.glob('*.out'):
	os.remove(fl)

for fl in glob.glob('*.56'):
	os.remove(fl)


os.chdir(cwd)
