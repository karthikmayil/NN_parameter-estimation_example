import numpy as np
import pandas as pd
from scipy.interpolate import interp1d
import os

iterations = []
for file in os.listdir():
    if file.startswith('Simulation_Parameters'):
        iterations.append(int(file.split('_I')[1].split('.')[0]))
        
i_latest = np.max(iterations)
latest_iteration_filename = f'Simulation_Parameters_I{i_latest}.csv'
sim_table = pd.read_csv(latest_iteration_filename,sep=',')

Vrange = np.array([2,3.6])
V_discrete = np.arange(Vrange[0],Vrange[1]+0.001,1/1000).round(3)

Q_f_Vs = []
for i in sim_table.index:
    TVT = pd.read_csv('Simulations/'+str(i)+'/Time_Voltage.txt',delim_whitespace=True,skiprows=[1])
    #print(TVT)
    TVT['SOD'] = TVT.Time/(1/sim_table.loc[i,'CRATE'])

    if len(TVT)<=10:
        Q = -1*np.ones(len(V_discrete))
    else:
        f = interp1d(TVT.Voltage,TVT.SOD,bounds_error=False,fill_value=(TVT.SOD.values[-1],0))
        Q = f(V_discrete)
    
    Q_f_Vs.append(Q)
    
Q_matrix = pd.DataFrame(Q_f_Vs,columns=V_discrete) #.values
Q_matrix = Q_matrix.loc[Q_matrix.iloc[:,0]>=0.1]
Q_matrix = Q_matrix.loc[Q_matrix.iloc[:,0]<=1]
Q_matrix.to_csv('features.csv',index=True,sep=',')
